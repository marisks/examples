﻿define("epi-ecf-ui/component/Catalogs", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/topic",
    "dojo/dom-class",
    "dojo/string",
// epi shell
    "epi/shell/dgrid/util/misc",
// epi cms
    "epi-cms/asset/HierarchicalList",
    "epi-cms/core/ContentReference",
    "epi-cms/dgrid/formatters",
// commerce
    "./viewmodel/CatalogsViewModel",
// Resources
    "epi/i18n!epi/cms/nls/commerce.components.catalogs"
],

function (
// dojo
    declare,
    lang,
    on,
    topic,
    domClass,
    dojoString,
// epi shell
    misc,
// epi cms
    HierarchicalList,
    ContentReference,
    formatters,
// commerce
    CatalogsViewModel,
// Resources
    res
) {
    // module:
    //      epi-ecf-ui.component.Catalogs

    return declare([HierarchicalList], {
        // summary:
        //      Catalogs component.
        // tags:
        //      public

        noThumbnailClass: "epi-dgrid--no-thumbnail",

        catalogListClass: "epi-thumbnailContentList epi-thumbnailContentList--with-icon",

        showThumbnail: true,

        res: res,

        noDataMessages: res.nodatamessages,

        // To enable context change when search catalog entries
        triggerContextChange: true,

        // refreshOnEdit: [public] bool
        //      Force the browser to navigate to edit content page instead of only changing context.
        navigateOnEdit: false,

        modelClassName: CatalogsViewModel,

        postMixInProperties: function () {
            this.inherited(arguments);
            lang.mixin(this.modelBindingMap, { showCatalogThumbnails: ["showCatalogThumbnails"] });

            this.model.set("navigateOnEdit", this.navigateOnEdit);
        },

        _setShowCatalogThumbnailsAttr: function (value) {
            // summary:
            //      Set show catalog thumbnails attribute.
            // tags:
            //      protected

            var gridNode = this.list.grid.domNode;
            var searchListNode = this.searchResultList.grid.domNode;

            domClass.toggle(gridNode, this.catalogListClass);
            domClass.toggle(searchListNode, this.catalogListClass);

            if (!this.model.showCatalogThumbnails) {
                domClass.add(gridNode, this.noThumbnailClass);
                domClass.add(searchListNode, this.noThumbnailClass);
            } else {
                domClass.remove(gridNode, this.noThumbnailClass);
                domClass.remove(searchListNode, this.noThumbnailClass);
            }
        },

        getThumbnailSelector: function (item) {
            // summary:
            //      Get thumbnail url from content item.
            // tags:
            //      public

            if (item && item.properties) {
                return item.properties.thumbnail;
            }
            return '';
        },

        getTitleSelector: function (item) {
            // summary:
            //      Get title information from content item.
            // tags:
            //      public

            if (item) {
                var reference = new ContentReference(item.contentLink);
                if (reference) {
                        return item.properties.customToolTip;
                    }
            }
            return '';
        },

        _setFormatterForList: function (list) {
            // summary:
            //      Reset formatter for catalog hierarchical list.
            // tags:
            //      protected

            if (list) {
                var grid = list.grid;
                // Reset formatter for catalog list to display both thumbnail and icon type identifier
                grid.formatters = [lang.hitch(this, this.catalogItemFormatter)];
                grid.configStructure();
            }
        },

        catalogItemFormatter: function (value, object, node, options) {
            // summary:
            //      Formatter for catalog list to display both thumbnail and icon type identifier.
            // tags:
            //      public

            var text = misc.htmlEncode(object.name);
            var title = misc.attributeEncode(this.getTitleSelector(object) || text);
            var returnValue = dojoString.substitute("${thumbnail} ${icon} ${text}", {
                thumbnail: formatters.thumbnail(this.getThumbnailSelector(object)),
                icon: formatters.contentIcon(object.typeIdentifier),
                text: misc.ellipsis(text, title)
            });

            node.innerHTML = returnValue;
            return returnValue;
        },

        startup: function () {
            // summary:
            //      Adds the breadcrumb widget to the top of the list widget.
            // tags:
            //      protected
            this.inherited(arguments);

            this.own(topic.subscribe("relationChanged", lang.hitch(this, function () {
                this.list._updateQuery(this.list.query);
            })));
            // disable DnD action on this gadget
            this.tree.dndController.readOnly = true;

            this._setFormatterForList(this.list);
            this._setFormatterForList(this.searchResultList);

            this.searchBox.triggerContextChange = false;
        },

        setupContextMenu: function () {
            // summary: set up the context menu. Overrriden to not add context menu on the catalog tree gadget
            //
            // tag:
            //      public override

        }
    });
});