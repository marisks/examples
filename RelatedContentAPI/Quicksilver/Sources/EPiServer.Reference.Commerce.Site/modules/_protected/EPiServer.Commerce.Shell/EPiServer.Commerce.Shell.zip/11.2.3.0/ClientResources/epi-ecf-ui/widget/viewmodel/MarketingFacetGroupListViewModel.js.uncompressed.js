﻿define("epi-ecf-ui/widget/viewmodel/MarketingFacetGroupListViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/when",
// epi
    "epi/dependency",

    "epi-ecf-ui/widget/viewmodel/FacetGroupListViewModel"
], function (
// dojo
    declare,
    lang,

    when,
// epi
    dependency,

    FacetGroupListViewModel
) {

    return declare([FacetGroupListViewModel], {
        // summary:
        //      View model for marketing "FacetGroupList" widget.
        // tags:
        //      public

        facetStoreKeyName: "epi.commerce.facet",

        postscript: function () {
            var registry = dependency.resolve("epi.storeregistry");
            this.store = this.store || registry.get(this.facetStoreKeyName);

            this._campaignRootFolder = this._campaignRootFolder || dependency.resolve("epi.cms.contentRepositoryDescriptors").marketing.roots[0];

            this.inherited(arguments);
        },

        _getData: function () {
            // summary:
            //      Gets campaign facets data.
            // tags:
            //      protected, extensions

            var query = {
                "id": "campaignFacet",
                facetString: this._facetFiltersService.getFiltersAsJson(),
                parentLink: this._campaignRootFolder
            };

            return this.store.query(query);
        }

    });

});