﻿define("epi-ecf-ui/command/MarketingToolbarCommandProvider", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dijit/Destroyable",
    "dijit/form/ToggleButton",
    "epi/shell/command/ToggleCommand",
    "epi-cms/component/command/_GlobalToolbarCommandProvider",
    "epi-cms/widget/command/CreateContentFromSelector",
    "../MarketingUtils",
    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting"
], function(
    declare,
    lang,
    topic,
    Destroyable,
    ToggleButton,
    ToggleCommand,
    _GlobalToolbarCommandProvider,
    CreateContentFromSelector,
    MarketingUtils,
    // Resources
    resources
) {

    //Copied from episerver-ui
    //http://stash01:7990/projects/SH/repos/episerver-ui/browse/EPiServer.Cms.Shell.UI/UI/ClientResources/epi-cms/component/command/GlobalToolbarCommandProvider.js?at=e10aef906d6fea33cc3cd328614c0a08c6f65fdd#81
    var _ToggleAssetsPaneCommand = declare([ToggleCommand, Destroyable], {
        iconClass: "epi-iconFolder",
        tooltip: resources.toolbar.buttons.toggleassetspane,
        label: resources.toolbar.buttons.toggleassetspane,
        canExecute: true,
        constructor: function () {
            this.own(
                topic.subscribe("/epi/layout/pinnable/tools/visibilitychanged", lang.hitch(this, function (visible) {
                    this.set("active", visible);
                }))
            );
        },
        _execute: function () {
            topic.publish("/epi/layout/pinnable/tools/toggle");
        }
    });

    return declare([_GlobalToolbarCommandProvider], {

        contentRepositoryDescriptors: null,
        viewName: null,

        postscript: function () {
            this.inherited(arguments);

            this.addToTrailing(new _ToggleAssetsPaneCommand(), {
                widget: ToggleButton,
                "class": "epi-trailingToggleButton epi-mediumButton"
            });

            this.newCampaignCommand = new CreateContentFromSelector({
                creatingTypeIdentifier: MarketingUtils.contentTypeIdentifier.salesCampaign
            });
            this.newPromotionCommand = new CreateContentFromSelector({
                creatingTypeIdentifier: MarketingUtils.contentTypeIdentifier.promotionData
            });
            //If you want to add new types to create here: consider making it more generic and use repository descriptors as GlobalToolbarCommandProvider does in cms.
            this.addCommand(this.newCampaignCommand, { category: "create" });
            this.addCommand(this.newPromotionCommand, { category: "create" });
        }
    });
});
