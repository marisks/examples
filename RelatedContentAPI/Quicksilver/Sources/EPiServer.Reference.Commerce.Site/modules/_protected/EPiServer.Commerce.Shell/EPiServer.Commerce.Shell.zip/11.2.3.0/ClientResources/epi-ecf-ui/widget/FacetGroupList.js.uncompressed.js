require({cache:{
'url:epi-ecf-ui/widget/templates/FacetGroupList.html':"﻿﻿<div class=\"epi-facet-list\">\r\n    <div data-dojo-attach-point=\"containerNode\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/FacetGroupList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/topic",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi",
    "epi/shell/widget/_ModelBindingMixin",

    "./FacetGroup",
// resources
    "dojo/text!./templates/FacetGroupList.html"
], function (
// dojo
    declare,
    lang,

    topic,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    epi,
    _ModelBindingMixin,

    FacetGroup,
// resources
    template
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //      Represents the widget to filter list of campaigns.
        // tags:
        //      public

        modelBindingMap: {
            facetGroups: ["facetGroups"],
            facetGroupsItems: ["facetGroupsItems"]
        },

        _setFacetGroupsAttr: function (facetGroups) {
            // summary:
            //      Renders facet groups.
            // facetGroups: [Array]
            //      Collection of facet group.
            // tags:
            //      protected

            facetGroups.forEach(function (facetGroup) {
                var facetGroupWidget = this._createFacetGroupWidget(facetGroup);
                this.addChild(facetGroupWidget);

                this.own(
                    facetGroupWidget,
                    facetGroupWidget.on("selection-changed", lang.hitch(this, this._onSelectionChanged))
                );
            }, this);

            this._updateFacetGroupWidgets();
        },

        _setFacetGroupsItemsAttr: function (facetGroupsItems) {
            // summary:
            //      Renders facet group's lists.
            // facetGroupsItems: [Object]
            //      Collection of facet group's items.
            // tags:
            //      protected

            this.getChildren().forEach(function (facetGroupWidget) {
                var facetGroupItems = facetGroupsItems[facetGroupWidget.model.get("id")];
                if (epi.isEmpty(facetGroupItems)) {
                    return;
                }

                facetGroupWidget.model.set("recalculatedItems", facetGroupItems);
            }, this);
        },

        // itemViewModelClass: [public] string
        //      Facet group view model class.
        itemViewModelClass: null,

        // listViewModelClass: [public] string
        //      Facet group list view model class.
        listViewModelClass: null,

        // templateString: [public] string
        //      Used by _TemplatedMixin.
        templateString: template,

        postMixInProperties: function () {
            // tags:
            //      protected, extensions

            this.inherited(arguments);
            // Gets or create a new instance of view model class.
            this.model = this.model || new this.listViewModelClass();
        },

        postCreate: function () {
            // tags:
            //      protected, extensions

            this.inherited(arguments);

            // Fetches facet groups data in order to render the list of facet group.
            this.model.fetchData();

            // Each time turned back to main view, refresh this widget.
            this.own(
                topic.subscribe("/dojo/hashchange", lang.hitch(this, this._onHashChanged)),
                topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, this._onViewChanged)),
                this.watch("currentView", lang.hitch(this, this._onCurrentViewChanged))
            );
        },

        _createFacetGroupWidget: function (facetGroup) {
            // summary:
            //      Creates facet group widget based on the given settings.
            // facetGroup: [Object]
            //      Facet group settings.
            // returns: [Object]
            //      An instance of "epi-ecf-ui/widget/FacetGroup" widget.
            // tags:
            //      private

            return new FacetGroup({
                model: new this.itemViewModelClass({
                    name: facetGroup.name,
                    id: facetGroup.id,
                    listStore: facetGroup.items,
                    showMatchingItems: facetGroup.settings.showMatchingItems,
                    collapsible: facetGroup.settings.collapsible,
                    itemsToShow: facetGroup.settings.itemsToShow,
                    selectionType: facetGroup.settings.selectionType,
                    hasIcons: facetGroup.settings.hasIcons
                })
            });
        },

        _updateFacetGroupWidgets: function () {
            var hashFacetFilters = this.model.get("hashFacetFilters");
            this.model.set("facetFilters", hashFacetFilters);

            this.getChildren().forEach(function (groupWidget) {
                var facetFilter = hashFacetFilters.filter(function (item) {
                    return item.id === groupWidget.model.get("id");
                })[0];

                groupWidget.set("selection", facetFilter ? facetFilter.values : []);
            }, this);
        },

        _onHashChanged: function (newHash) {
            this.model.fetchRecalculatedData();
            this._updateFacetGroupWidgets();
        },

        _onViewChanged: function (type, args, data) {
            var currentView = data.viewName;
            if (!this.get("mainView")) {
                this._set("mainView", currentView);
            }

            this._set("currentView", currentView);
        },

        _onCurrentViewChanged: function (name, oldValue, value) {
            if (oldValue && this.get("mainView") === value) {
                this.model.fetchRecalculatedData();
            }
        },

        _onSelectionChanged: function (evt) {
            this.model.updateFacetFilter(evt.id, evt.items);
            this.model.setHashFacetFilters();
        }

    });

});